import re, sys
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
if 'android.permission.INTERNET' not in s:
    s = re.sub(r'(<manifest[^>]*>)',
               r'\1\n    <uses-permission android:name="android.permission.INTERNET"/>',
               s, count=1)
s = re.sub(r'(<application[^>]*?android:label=")[^"]*(")', r'\1توب لايف\2', s, count=1)
open(p, 'w', encoding='utf-8').write(s)
print(s)
if 'android.permission.INTERNET' not in s:
    sys.exit('INTERNET permission missing')
