import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'data.dart';

// ألوان وروابط الموقع (نفس ألوان الموقع بالضبط)
const kBg = Color(0xFF0C0A07), kPanel = Color(0xFF15110B), kPanel2 = Color(0xFF1C160D);
const kLine = Color(0xFF2E2517), kFg = Color(0xFFF4ECD8), kMuted = Color(0xFFA89C82);
const kGold = Color(0xFFEAB84B), kOnGold = Color(0xFF1A1204), kRed = Color(0xFFC6232B);
const site = 'https://toplifelibya.ly';
const discord = 'https://discord.com/invite/G4PXDPd9dy';
const shopCh = 'https://discord.com/channels/919255411704610897/1558848153824919602';
const ip = '51.83.49.125:16538';

Future<void> go(String u) => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    final base = ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      scaffoldBackgroundColor: kBg,
      colorScheme: const ColorScheme.dark(primary: kGold, surface: kPanel),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'توب لايف',
      theme: base.copyWith(textTheme: GoogleFonts.tajawalTextTheme(base.textTheme).apply(bodyColor: kFg, displayColor: kFg)),
      builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: const [Home(), RulesPage(), ShopPage(), SectorsPage(), AccountPage()][i],
        bottomNavigationBar: NavigationBar(
          backgroundColor: kPanel,
          indicatorColor: kGold.withOpacity(.2),
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_rounded), selectedIcon: Icon(Icons.home_rounded, color: kGold), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.gavel_rounded), selectedIcon: Icon(Icons.gavel_rounded, color: kGold), label: 'القوانين'),
            NavigationDestination(icon: Icon(Icons.storefront_rounded), selectedIcon: Icon(Icons.storefront_rounded, color: kGold), label: 'المتجر'),
            NavigationDestination(icon: Icon(Icons.shield_rounded), selectedIcon: Icon(Icons.shield_rounded, color: kGold), label: 'القطاعات'),
            NavigationDestination(icon: Icon(Icons.person_rounded), selectedIcon: Icon(Icons.person_rounded, color: kGold), label: 'حسابي'),
          ],
        ),
      );
}

// ---------- عناصر مشتركة ----------
Widget panel(Widget c, {EdgeInsets p = const EdgeInsets.all(16), Color bd = kLine, VoidCallback? onTap}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: bd)),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(borderRadius: BorderRadius.circular(16), onTap: onTap, child: Padding(padding: p, child: c)),
      ),
    );

Widget btn(String t, VoidCallback f, {bool ghost = false}) {
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(10));
  final label = Text(t, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16));
  return SizedBox(
    height: 50,
    width: double.infinity,
    child: ghost
        ? OutlinedButton(onPressed: f, style: OutlinedButton.styleFrom(foregroundColor: kFg, side: const BorderSide(color: Colors.white38), shape: shape), child: label)
        : FilledButton(onPressed: f, style: FilledButton.styleFrom(backgroundColor: kGold, foregroundColor: kOnGold, shape: shape), child: label),
  );
}

Widget h2(String t, [String? s]) => Padding(
      padding: const EdgeInsets.fromLTRB(0, 22, 0, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
        if (s != null) Text(s, style: const TextStyle(color: kMuted, height: 1.6)),
      ]),
    );

Widget page(List<Widget> c) => SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: c));

Widget pill(String t, {Color bg = kGold, Color fg = kOnGold}) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
      child: Text(t, style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 13)),
    );

Widget chips(List<(String, String)> cats, String sel, void Function(String) on, Map<String, int> counts) => SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: [
        for (final c in cats)
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 8),
            child: GestureDetector(
              onTap: () => on(c.$1),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: sel == c.$1 ? kGold.withOpacity(.1) : kPanel,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: sel == c.$1 ? kGold : kLine),
                ),
                child: Row(children: [
                  Text(c.$2),
                  const SizedBox(width: 8),
                  pill('${counts[c.$1] ?? 0}', bg: sel == c.$1 ? kGold : Colors.white10, fg: sel == c.$1 ? kOnGold : kMuted),
                ]),
              ),
            ),
          ),
      ]),
    );

// ---------- الرئيسية ----------
Future<String> fetchNews() async {
  try {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 6);
    final r = await (await c.getUrl(Uri.parse('$site/api/state'))).close();
    final j = jsonDecode(await r.transform(utf8.decoder).join());
    final v = jsonDecode(j['v'] as String);
    return (v is List && v.length > 2 && v[2] is String) ? v[2] as String : '';
  } catch (_) {
    return '';
  }
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: EdgeInsets.zero, children: [
        Stack(children: [
          ShaderMask(
            shaderCallback: (r) => const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black, Colors.black, Colors.transparent], stops: [0, .78, 1]).createShader(r),
            blendMode: BlendMode.dstIn,
            child: Image.asset('assets/cover.webp', width: double.infinity, fit: BoxFit.cover),
          ),
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xC70C0A07), Colors.transparent])),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                  child: Row(children: [
                    Image.asset('assets/logo.png', width: 36, height: 36),
                    const SizedBox(width: 10),
                    const Text('توب لايف للحياة الواقعية', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                  ]),
                ),
              ),
            ),
          ),
        ]),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                decoration: BoxDecoration(border: Border.all(color: Colors.white30), borderRadius: BorderRadius.circular(99)),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.circle, size: 8, color: kGold), SizedBox(width: 8), Text('السيزون الخامس'),
                ]),
              ),
            ),
            const SizedBox(height: 16),
            btn('انضم عبر الديسكورد', () => go(discord)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: btn('تقديم الإدارة', () => go('$site/apply'), ghost: true)),
              const SizedBox(width: 10),
              Expanded(child: btn('كيف أبدأ؟', () => go('$site/about#join'), ghost: true)),
            ]),
            const SizedBox(height: 16),
            FutureBuilder<String>(
              future: fetchNews(),
              builder: (c, s) => (s.data ?? '').isEmpty
                  ? const SizedBox()
                  : Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(color: kPanel2, borderRadius: BorderRadius.circular(10), border: Border.all(color: kLine)),
                      child: Row(children: [
                        Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), decoration: const BoxDecoration(color: kGold, borderRadius: BorderRadiusDirectional.horizontal(start: Radius.circular(10))), child: const Text('أخبار', style: TextStyle(color: kOnGold, fontWeight: FontWeight.w800))),
                        Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text(s.data!, maxLines: 2, overflow: TextOverflow.ellipsis))),
                      ]),
                    ),
            ),
            panel(Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('عنوان السيرفر', style: TextStyle(color: kMuted, fontSize: 13)),
                  const Text(ip, textDirection: TextDirection.ltr, style: TextStyle(fontFamily: 'monospace', fontSize: 18)),
                ]),
              ),
              OutlinedButton(
                style: OutlinedButton.styleFrom(foregroundColor: kGold, side: const BorderSide(color: Color(0xFFB8841F))),
                onPressed: () {
                  Clipboard.setData(const ClipboardData(text: ip));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ العنوان')));
                },
                child: const Text('نسخ العنوان', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ])),
            h2('مدينة كاملة بين يديك', 'شغل، عصابات، شرطة، إسعاف وميكانيكي. كل شيء في السيرفر له دور وقواعد، واللاعب هو من يصنع قصته.'),
            for (final f in const [
              ('وظائف حقيقية', 'صياد سمك، سائق شاحنة، نقل نفايات وغيرها. مستوى مهارتك يرتفع كلما اشتغلت.'),
              ('جهات رسمية', 'الداخلية والدفاع والقوات الخاصة والصحة والميكانيكي، لكل جهة رتبها ونظامها.'),
              ('ممتلكات وحقيبة', 'بيوت وسيارات وحقيبة بعشرين خانة تحمل فيها أغراضك وأسلحتك.'),
              ('حسابك محمي', 'كل حساب مربوط بحساب ديسكورد واحد بموافقة الإدارة، بلا حسابات مكررة.'),
            ])
              panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(f.$1, style: const TextStyle(color: kGold, fontWeight: FontWeight.w700, fontSize: 19)),
                const SizedBox(height: 4),
                Text(f.$2, style: const TextStyle(color: kMuted, height: 1.7)),
              ])),
            h2('كيف تنضم؟', 'أربع خطوات، وتدخل المدينة بعد موافقة الإدارة على حسابك.'),
            for (final s in const [
              ('ادخل سيرفر الديسكورد', 'تحتاج دور «عضو» في الديسكورد قبل أن تسجل.'),
              ('افتح سامب وادخل السيرفر', 'استخدم العنوان بالأعلى في سامب للجوال أو للكمبيوتر.'),
              ('سجّل حساباً جديداً', 'اكتب اسمك، كلمة السر، يوزر الديسكورد، العمر والجنس، ثم اختر شخصيتك.'),
              ('انتظر الربط', 'الإدارة تراجع الطلب في الديسكورد وتصلك رسالة بالقبول أو بسبب الرفض.'),
            ].indexed)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: const BoxDecoration(border: Border(top: BorderSide(color: kLine))),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SizedBox(width: 44, child: Text('${s.$1 + 1}', style: const TextStyle(color: kGold, fontSize: 30, fontWeight: FontWeight.w700, height: 1))),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(s.$2.$1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                    Text(s.$2.$2, style: const TextStyle(color: kMuted, height: 1.6)),
                  ])),
                ]),
              ),
            const SizedBox(height: 24),
            const Center(child: Text('توب لايف رول بلاي · السيزون 5\nسيرفر مجتمعي غير تابع لـ Rockstar Games', textAlign: TextAlign.center, style: TextStyle(color: kMuted, fontSize: 13, height: 1.7))),
          ]),
        ),
      ]);
}

// ---------- القوانين ----------
class RulesPage extends StatefulWidget {
  const RulesPage({super.key});
  @override
  State<RulesPage> createState() => _RulesPageState();
}

class _RulesPageState extends State<RulesPage> {
  String cat = 'discord';
  static const cats = [('discord', 'قوانين الديسكورد'), ('game', 'قوانين اللعبة'), ('gangs', 'قوانين العصابات')];
  @override
  Widget build(BuildContext context) {
    final list = rules.where((r) => r.cat == cat).toList();
    final counts = {for (final c in cats) c.$1: rules.where((r) => r.cat == c.$1).length};
    return page([
      h2('القوانين', 'قوانين السيرفر التي يلتزم بها كل لاعب.'),
      chips(cats, cat, (v) => setState(() => cat = v), counts),
      const SizedBox(height: 16),
      if (list.isEmpty) panel(const Center(child: Text('قريباً\nنجهّز هذه القوانين وستُنشر هنا قريباً.', textAlign: TextAlign.center, style: TextStyle(color: kMuted, height: 1.8)))),
      for (final r in list)
        panel(Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          pill('#${r.num}'),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(r.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
              const SizedBox(height: 6),
              Text(r.body, style: const TextStyle(color: kMuted, height: 1.9)),
              if (r.pen.isNotEmpty) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(color: kRed.withOpacity(.14), border: Border.all(color: kRed.withOpacity(.45)), borderRadius: BorderRadius.circular(10)),
                  child: Text('العقوبة: ${r.pen}', style: const TextStyle(color: Color(0xFFFF6B6B), fontWeight: FontWeight.w700, fontSize: 13)),
                ),
              ],
            ]),
          ),
        ])),
    ]);
  }
}

// ---------- المتجر ----------
class Product {
  final String cat, name, desc, img;
  final int price;
  const Product(this.cat, this.name, this.desc, this.price, this.img);
}

const products = [
  Product('seasonal', 'حزمة شفرليت اوبترا', 'سيارة اوبترا، مسدس مع 10 ذخيرة، كليشتان، و100 طعام وشراب.', 55, 'pack1.webp'),
  Product('seasonal', 'حزمة لبوة مصفحة', 'سيارة لاند كروزر، 15000 دينار، وفيلا من اختيارك.', 75, 'pack2.webp'),
  Product('seasonal', 'حزمة سرليون مصفحة', 'سيارة سرليون، 50 درع فل، 150 طعام وشراب، و15 ألف دينار.', 80, 'pack3.webp'),
  Product('ids', 'آيدي 11', 'آيدي مميز رقم 11 لحسابك داخل السيرفر.', 30, 'ids.webp'),
  Product('ids', 'آيدي 444', 'آيدي مميز رقم 444 لحسابك داخل السيرفر.', 40, 'ids.webp'),
  Product('ids', 'آيدي 55', 'آيدي مميز رقم 55 لحسابك داخل السيرفر.', 30, 'ids.webp'),
];

class ShopPage extends StatefulWidget {
  const ShopPage({super.key});
  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  String cat = 'all';
  static const cats = [('all', 'الكل'), ('seasonal', 'حزم موسمية'), ('ids', 'الايديات')];
  @override
  Widget build(BuildContext context) {
    final list = products.where((p) => cat == 'all' || p.cat == cat).toList();
    final counts = {for (final c in cats) c.$1: products.where((p) => c.$1 == 'all' || p.cat == c.$1).length};
    final w = (MediaQuery.of(context).size.width - 32 - 12) / 2;
    return page([
      h2('المتجر', 'حزم جاهزة بسيارات وأغراض ومكافآت تبدأ بها قصتك بقوة.'),
      chips(cats, cat, (v) => setState(() => cat = v), counts),
      const SizedBox(height: 16),
      Wrap(spacing: 12, runSpacing: 12, children: [
        for (final p in list)
          SizedBox(
            width: w,
            child: Container(
              decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: kLine)),
              clipBehavior: Clip.antiAlias,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                AspectRatio(aspectRatio: 512 / 720, child: Image.asset('assets/${p.img}', fit: BoxFit.cover)),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(p.desc, style: const TextStyle(color: kMuted, fontSize: 12.5, height: 1.6)),
                    const Divider(color: kLine, height: 20),
                    Row(children: [
                      Text('${p.price}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                      const SizedBox(width: 4),
                      const Text('TL', style: TextStyle(color: kGold, fontWeight: FontWeight.w700)),
                      const Spacer(),
                      FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: kGold, foregroundColor: kOnGold, padding: const EdgeInsets.symmetric(horizontal: 16), minimumSize: const Size(0, 38)),
                        onPressed: () => go('$site/shop'),
                        child: const Text('شراء', style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ]),
                  ]),
                ),
              ]),
            ),
          ),
      ]),
      const SizedBox(height: 20),
      btn('اشترِ الحزمة من الديسكورد', () => go(shopCh)),
      const SizedBox(height: 10),
      btn('محفظتي', () => go('$site/wallet'), ghost: true),
    ]);
  }
}

// ---------- القطاعات ----------
class SectorsPage extends StatelessWidget {
  const SectorsPage({super.key});
  static const items = [
    ('interior', 'الداخلية', 'حفظ الأمن والتعامل مع البلاغات داخل المدينة.', 'logo-interior.webp'),
    ('defense', 'الدفاع', 'حماية المدينة والمنشآت الحيوية.', 'logo-defense.webp'),
    ('special', 'القوات الخاصة', 'مهام خاصة وعمليات عالية الخطورة.', 'logo-special.webp'),
    ('health', 'الصحة', 'الإسعاف وإنقاذ المصابين وعلاجهم.', 'icon-192.png'),
    ('mechanic', 'الميكانيكي', 'إصلاح وصيانة سيارات اللاعبين.', 'icon-192.png'),
  ];
  @override
  Widget build(BuildContext context) => page([
        h2('القطاعات', 'الجهات الرسمية في المدينة، ولكل قطاع رتبه ونظامه.'),
        for (final s in items)
          panel(
            onTap: () => go('$site/sector/${s.$1}'),
            Row(children: [
              ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/${s.$4}', width: 76, height: 76, fit: BoxFit.cover)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.$2, style: const TextStyle(color: kGold, fontWeight: FontWeight.w700, fontSize: 19)),
                  Text(s.$3, style: const TextStyle(color: kMuted, height: 1.6)),
                  const SizedBox(height: 4),
                  const Text('ادخل القطاع ←', style: TextStyle(color: kGold, fontWeight: FontWeight.w700, fontSize: 13)),
                ]),
              ),
            ]),
          ),
      ]);
}

// ---------- حسابي ----------
class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) => page([
        const SizedBox(height: 24),
        Center(child: Image.asset('assets/logo.png', width: 84)),
        const SizedBox(height: 12),
        const Center(child: Text('حسابي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700))),
        const Center(child: Text('سجّل دخولك بالديسكورد لإدارة محفظتك وشراء الحزم', textAlign: TextAlign.center, style: TextStyle(color: kMuted, height: 1.7))),
        const SizedBox(height: 20),
        btn('تسجيل الدخول بالديسكورد', () => go('$site/auth/login')),
        const SizedBox(height: 10),
        btn('محفظتي', () => go('$site/wallet'), ghost: true),
        const SizedBox(height: 10),
        btn('تقديم الإدارة', () => go('$site/apply'), ghost: true),
        const SizedBox(height: 10),
        btn('سيرفر الديسكورد', () => go(discord), ghost: true),
        const SizedBox(height: 20),
        panel(
          bd: const Color(0xFFB8841F),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('1 دينار = 1 TL', style: TextStyle(color: kGold, fontSize: 28, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('عملة السيرفر الخاصة بالحزم والمزايا. اشحن رصيدك من المحفظة وتتم الموافقة بعد التأكد من التحويل، ويُضاف الرصيد لحسابك المربوط فقط.', style: TextStyle(color: kMuted, height: 1.8)),
          ]),
        ),
      ]);
}
