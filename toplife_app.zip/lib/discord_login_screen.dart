import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kDiscordClientId = '1248804389414506526';
const String kDiscordRedirectUri = 'https://toplifelibya.ly/auth/callback';

class DiscordLoginScreen extends StatefulWidget {
  const DiscordLoginScreen({super.key});

  @override
  State<DiscordLoginScreen> createState() => _DiscordLoginScreenState();
}

class _DiscordLoginScreenState extends State<DiscordLoginScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _done = false;
  String? _error;

  static final String _authUrl = Uri.https('discord.com', '/oauth2/authorize', {
    'client_id': kDiscordClientId,
    'redirect_uri': kDiscordRedirectUri,
    'response_type': 'code',
    'scope': 'identify',
  }).toString();

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36')
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (request) {
          if (request.url.startsWith(kDiscordRedirectUri)) {
            _handleRedirect(request.url);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
        onPageStarted: (_) {
          if (mounted) setState(() => _loading = true);
        },
        onWebResourceError: (e) {
          if (e.isForMainFrame == true && mounted) {
            setState(() {
              _loading = false;
              _error = '${e.errorCode}: ${e.description}';
            });
          }
        },
        onPageFinished: (_) {
          if (mounted) setState(() => _loading = false);
        },
      ))
      ..loadRequest(Uri.parse(_authUrl));
  }

  void _handleRedirect(String url) {
    if (_done) return;
    _done = true;
    final code = Uri.parse(url).queryParameters['code'];
    if (mounted) Navigator.pop(context, code);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول عبر ديسكورد')),
      body: Stack(children: [
        WebViewWidget(controller: _controller),
        if (_error != null)
          Container(
            color: Colors.black,
            alignment: Alignment.center,
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('تعذّر تحميل الصفحة', style: TextStyle(fontSize: 18)),
              const SizedBox(height: 8),
              Text(_error!, textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() => _error = null);
                  _controller.loadRequest(Uri.parse(_authUrl));
                },
                child: const Text('إعادة المحاولة'),
              ),
            ]),
          ),
        if (_loading) const LinearProgressIndicator(),
      ]),
    );
  }
}
